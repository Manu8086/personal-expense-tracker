package com.expensetracker;

public class Expense {
    private String id;
    private double amount;
    private String category;
    private String note;
    private String date; // yyyy-MM-dd

    public Expense() {}

    public Expense(String id, double amount, String category, String note, String date) {
        this.id = id;
        this.amount = amount;
        this.category = category;
        this.note = note;
        this.date = date;
    }

    public String getId() { return id; }
    public double getAmount() { return amount; }
    public String getCategory() { return category; }
    public String getNote() { return note; }
    public String getDate() { return date; }

    public void setId(String id) { this.id = id; }
    public void setAmount(double amount) { this.amount = amount; }
    public void setCategory(String category) { this.category = category; }
    public void setNote(String note) { this.note = note; }
    public void setDate(String date) { this.date = date; }

    @Override
    public String toString() {
        return String.format("%s | %s | %.2f | %s%s", id, date, amount, category, (note!=null && !note.isEmpty()?" ("+note+")":""));
    }
}
