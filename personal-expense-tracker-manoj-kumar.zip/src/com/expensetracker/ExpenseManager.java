package com.expensetracker;

import java.io.*;
import java.util.*;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ExpenseManager {
    private List<Expense> expenses = new ArrayList<>();
    private File dataFile;
    private Gson gson = new Gson();
    private DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public ExpenseManager(String dataPath) {
        this.dataFile = new File(dataPath);
        File p = this.dataFile.getParentFile();
        if (p != null) p.mkdirs();
        load();
    }

    public void addExpense(Expense e) {
        expenses.add(e);
        save();
    }

    public List<Expense> listAll() {
        return new ArrayList<>(expenses);
    }

    public Expense findById(String id) {
        for (Expense e : expenses) if (e.getId().equals(id)) return e;
        return null;
    }

    public boolean updateExpense(String id, double amount, String date, String note, String category) {
        Expense e = findById(id);
        if (e == null) return false;
        e.setAmount(amount);
        e.setDate(date);
        e.setNote(note);
        e.setCategory(category);
        save();
        return true;
    }

    public boolean deleteExpense(String id) {
        Expense e = findById(id);
        if (e == null) return false;
        expenses.remove(e);
        save();
        return true;
    }

    public void save() {
        try (Writer w = new FileWriter(dataFile)) {
            gson.toJson(expenses, w);
        } catch (IOException ex) {
            System.err.println("Failed to save data: " + ex.getMessage());
        }
    }

    private void load() {
        if (!dataFile.exists()) {
            expenses = new ArrayList<>();
            return;
        }
        try (Reader r = new FileReader(dataFile)) {
            Type listType = new TypeToken<List<Expense>>(){}.getType();
            List<Expense> loaded = gson.fromJson(r, listType);
            if (loaded != null) expenses = loaded;
            else expenses = new ArrayList<>();
        } catch (Exception ex) {
            System.err.println("Failed to load data: " + ex.getMessage());
            expenses = new ArrayList<>();
        }
    }

    // Filters
    public List<Expense> filterByCategory(String category) {
        List<Expense> res = new ArrayList<>();
        for (Expense e : expenses) if (e.getCategory().equalsIgnoreCase(category)) res.add(e);
        return res;
    }

    public List<Expense> filterByDateRange(String from, String to) {
        LocalDate f = LocalDate.parse(from, fmt);
        LocalDate t = LocalDate.parse(to, fmt);
        List<Expense> res = new ArrayList<>();
        for (Expense e : expenses) {
            LocalDate d = LocalDate.parse(e.getDate(), fmt);
            if ((d.isEqual(f) || d.isAfter(f)) && (d.isEqual(t) || d.isBefore(t))) res.add(e);
        }
        return res;
    }

    // Summaries
    public double totalSpent() {
        double s = 0;
        for (Expense e : expenses) s += e.getAmount();
        return s;
    }

    public Map<String, Double> totalByCategory() {
        Map<String, Double> m = new HashMap<>();
        for (Expense e : expenses) {
            m.putIfAbsent(e.getCategory(), 0.0);
            m.put(e.getCategory(), m.get(e.getCategory()) + e.getAmount());
        }
        return m;
    }

    public Map<String, Double> totalByMonth() {
        Map<String, Double> m = new HashMap<>();
        for (Expense e : expenses) {
            String month = e.getDate().substring(0,7); // yyyy-MM
            m.putIfAbsent(month, 0.0);
            m.put(month, m.get(month) + e.getAmount());
        }
        return m;
    }
}
