package com.expensetracker;

import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class Main {
    private static final String DATA_PATH = "data/data.json";
    private static final List<String> CATEGORIES = Arrays.asList("Food","Travel","Bills","Entertainment","Other");
    private static final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static void main(String[] args) {
        ExpenseManager mgr = new ExpenseManager(DATA_PATH);
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("---- Personal Expense Tracker ----");
            System.out.println("1. Add Expense");
            System.out.println("2. View Expenses");
            System.out.println("3. Update Expense");
            System.out.println("4. Delete Expense");
            System.out.println("5. Summary Reports");
            System.out.println("6. Filters");
            System.out.println("7. Exit");
            System.out.print("Choose option: ");
            String opt = sc.nextLine().trim();
            switch (opt) {
                case "1": addExpense(sc, mgr); break;
                case "2": viewExpenses(mgr); break;
                case "3": updateExpense(sc, mgr); break;
                case "4": deleteExpense(sc, mgr); break;
                case "5": showSummary(mgr); break;
                case "6": filters(sc, mgr); break;
                case "7": System.out.println("Goodbye!"); sc.close(); return;
                default: System.out.println("Invalid option\n"); break;
            }
        }
    }

    private static void addExpense(Scanner sc, ExpenseManager mgr) {
        try {
            System.out.print("Enter amount: ");
            String a = sc.nextLine().trim();
            double amount = Double.parseDouble(a);
            if (amount < 0) { System.out.println("Amount must be positive\n"); return; }

            System.out.println("Select category: " + CATEGORIES);
            System.out.print("Enter category: ");
            String category = sc.nextLine().trim();
            final String cat = category;
            if (!CATEGORIES.stream().anyMatch(x -> x.equalsIgnoreCase(cat))) {
                System.out.println("Unknown category, defaulting to 'Other'\n");
                category = "Other";
            } else {
                // normalize to canonical case from CATEGORIES
                for (String c : CATEGORIES) if (c.equalsIgnoreCase(category)) { category = c; break; }
            }

            System.out.print("Enter date (yyyy-MM-dd) or leave empty for today: ");
            String date = sc.nextLine().trim();
            if (date.isEmpty()) date = LocalDate.now().format(fmt);
            else LocalDate.parse(date, fmt); // will throw if invalid

            System.out.print("Enter note (optional): ");
            String note = sc.nextLine().trim();

            String id = UUID.randomUUID().toString().substring(0,8);
            Expense e = new Expense(id, amount, category, note, date);
            mgr.addExpense(e);
            System.out.println("Expense added: " + e.toString() + "\n");
        } catch (Exception ex) {
            System.out.println("Failed to add expense: " + ex.getMessage() + "\n");
        }
    }

    private static void viewExpenses(ExpenseManager mgr) {
        List<Expense> all = mgr.listAll();
        if (all.isEmpty()) {
            System.out.println("No expenses found.\n"); return;
        }
        System.out.println("ID | Date | Amount | Category (note)");
        System.out.println("--------------------------------------");
        for (Expense e : all) System.out.println(e.toString());
        System.out.println("--------------------------------------");
        System.out.printf("Total: %.2f\n\n", mgr.totalSpent());
    }

    private static void updateExpense(Scanner sc, ExpenseManager mgr) {
        try {
            System.out.print("Enter expense ID to update: ");
            String id = sc.nextLine().trim();
            Expense e = mgr.findById(id);
            if (e == null) { System.out.println("Not found\n"); return; }
            System.out.println("Current: " + e.toString());
            System.out.print("New amount (leave empty to keep): ");
            String a = sc.nextLine().trim();
            double amount = a.isEmpty() ? e.getAmount() : Double.parseDouble(a);
            System.out.print("New date (yyyy-MM-dd) (leave empty to keep): ");
            String date = sc.nextLine().trim();
            if (date.isEmpty()) date = e.getDate(); else LocalDate.parse(date, fmt);
            System.out.print("New category (leave empty to keep): ");
            String category = sc.nextLine().trim();
            if (category.isEmpty()) category = e.getCategory();
            System.out.print("New note (leave empty to keep): ");
            String note = sc.nextLine().trim();
            if (note.isEmpty()) note = e.getNote();
            boolean ok = mgr.updateExpense(id, amount, date, note, category);
            System.out.println(ok ? "Updated successfully\n" : "Update failed\n");
        } catch (Exception ex) {
            System.out.println("Failed to update: " + ex.getMessage() + "\n");
        }
    }

    private static void deleteExpense(Scanner sc, ExpenseManager mgr) {
        System.out.print("Enter expense ID to delete: ");
        String id = sc.nextLine().trim();
        boolean ok = mgr.deleteExpense(id);
        System.out.println(ok ? "Deleted successfully\n" : "Not found\n");
    }

    private static void showSummary(ExpenseManager mgr) {
        System.out.printf("Total spent: %.2f\n", mgr.totalSpent());
        System.out.println("By category:");
        for (Map.Entry<String, Double> entry : mgr.totalByCategory().entrySet()) {
            System.out.printf("  %s : %.2f\n", entry.getKey(), entry.getValue());
        }
        System.out.println("By month:");
        for (Map.Entry<String, Double> entry : mgr.totalByMonth().entrySet()) {
            System.out.printf("  %s : %.2f\n", entry.getKey(), entry.getValue());
        }
        System.out.println();
    }

    private static void filters(Scanner sc, ExpenseManager mgr) {
        System.out.println("1. Filter by category\n2. Filter by date range\nChoose: ");
        String opt = sc.nextLine().trim();
        switch(opt) {
            case "1":
                System.out.print("Enter category: ");
                String cat = sc.nextLine().trim();
                List<Expense> list = mgr.filterByCategory(cat);
                if (list.isEmpty()) System.out.println("No results\n");
                else { for (Expense e : list) System.out.println(e.toString()); System.out.println(); }
                break;
            case "2":
                try {
                    System.out.print("From (yyyy-MM-dd): ");
                    String from = sc.nextLine().trim();
                    System.out.print("To (yyyy-MM-dd): ");
                    String to = sc.nextLine().trim();
                    List<Expense> lr = mgr.filterByDateRange(from, to);
                    if (lr.isEmpty()) System.out.println("No results\n");
                    else { for (Expense e : lr) System.out.println(e.toString()); System.out.println(); }
                } catch (Exception ex) { System.out.println("Invalid date\n"); }
                break;
            default: System.out.println("Invalid\n"); break;
        }
    }
}
