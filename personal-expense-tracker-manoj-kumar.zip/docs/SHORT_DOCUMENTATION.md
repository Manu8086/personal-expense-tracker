# Short Documentation

## Assumptions
- Runs on Windows via Command Prompt.
- Data stored locally in data/data.json.
- Categories: Food, Travel, Bills, Entertainment, Other.

## Design
- Expense.java: model
- ExpenseManager.java: manages list, persistence, filters, summaries
- Main.java: CLI interaction & menu

## Sample Input/Output
Add expense:
Enter amount: 12.50
Enter category: Food
Enter date: 2025-10-04
Enter note: Lunch at cafe

Output when viewing:
ID | Date | Amount | Category (note)
--------------------------------------
a1b2c3d4 | 2025-10-01 | 12.50 | Food (Lunch at café)
--------------------------------------
Total: 12.50
